# EC2 Browser Worker Integration

> How the Hatchet orchestrator (VALET worker on Fly.io) dispatches browser automation
> tasks to a Python FastAPI worker running on EC2 with AdsPower + Stagehand/Magnitude.
>
> Replaces the Fly Machines sandbox model from `02-sandbox-deployment.md` with an
> EC2 persistent-VM pool model. Reference implementation:
> [axon-browser-worker](https://github.com/Shluo03/axon-browser-worker).

---

## Table of Contents

1. [Architecture Overview](#1-architecture-overview)
2. [EC2 Worker API Contract](#2-ec2-worker-api-contract)
3. [Hatchet Workflow Mapping](#3-hatchet-workflow-mapping)
4. [Session Lifecycle](#4-session-lifecycle)
5. [Progress & Callback Protocol](#5-progress--callback-protocol)
6. [Human-in-the-Loop](#6-human-in-the-loop)
7. [Profile & Pool Management](#7-profile--pool-management)
8. [Circuit Breaker & Error Handling](#8-circuit-breaker--error-handling)
9. [EC2 Golden Image (AMI)](#9-ec2-golden-image-ami)
10. [Networking & Security](#10-networking--security)
11. [Cost Model](#11-cost-model)
12. [Implementation Phases](#12-implementation-phases)

---

## 1. Architecture Overview

### Current State (All Mocked)

```
Frontend → API (task.service) → Hatchet event "task:created"
  → VALET Worker (Fly.io)
    → job-application workflow (7 steps, ALL MOCKED)
    → LinkedInMockAdapter, AdsPowerMockClient, BrowserAgentMock, etc.
```

### Target State

```
Frontend → API (task.service) → Hatchet event "task:created"
  → VALET Worker (Fly.io)
    → job-application workflow (orchestrator)
      ↓ HTTP calls
    → EC2 Browser Worker (Python FastAPI)
      → AdsPower Local API (browser profiles)
      → Stagehand / Magnitude (browser agents)
      → VNC (x11vnc + websockify for human takeover)
      ↓ Webhooks
    → VALET API (progress updates, pause signals)
```

### Key Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| EC2 instance type | t3.medium (2 vCPU / 4 GB) | Sufficient for Xvfb + Chromium + AdsPower; burstable for 2-3 min sessions |
| Pricing model | 1-year Reserved Instance | $22/mo vs $30/mo on-demand |
| Browser session model | Session-based (browser stays open across steps) | Hatchet steps need shared browser state |
| Communication | HTTP REST (worker → EC2) + Webhooks (EC2 → API) | Simple, debuggable, no persistent connections needed |
| Worker language | Python (FastAPI) | Matches axon-browser-worker reference; Stagehand & Magnitude both have Python SDKs |
| Profile assignment | Pool manager in VALET worker | Hatchet picks an idle profile before dispatching to EC2 |

---

## 2. EC2 Worker API Contract

The EC2 worker exposes a **session-based** REST API. Unlike axon-browser-worker's
stateless model (one call = one complete task), we keep the browser session open
across multiple Hatchet step calls.

### Base URL

```
http://{ec2-private-ip}:8080  (internal, behind VPN/security group)
```

### Endpoints

#### `POST /sessions` — Start Browser Session

Opens an AdsPower profile and navigates to the target URL.

```jsonc
// Request
{
  "task_id": "uuid",
  "profile_id": "ads-power-profile-id",
  "job_url": "https://linkedin.com/jobs/view/123",
  "callback_url": "https://valet-api.fly.dev/api/v1/webhooks/worker",
  "callback_token": "jwt-token-for-auth",
  "mode": "copilot"  // or "autopilot"
}

// Response 201
{
  "session_id": "uuid",
  "cdp_url": "ws://127.0.0.1:9222/devtools/browser/...",
  "vnc_url": "wss://{ec2-public-ip}:6901/websockify?session={session_id}",
  "status": "ready"
}
```

#### `POST /sessions/{id}/analyze` — Analyze Application Form

Detects platform and maps form fields using Stagehand/Magnitude.

```jsonc
// Response 200
{
  "platform": "linkedin",
  "is_easy_apply": true,
  "total_pages": 3,
  "fields": [
    {
      "name": "firstName",
      "label": "First Name",
      "type": "text",
      "required": true,
      "selector": "#firstName",
      "page_index": 0
    }
    // ...
  ],
  "has_file_upload": true,
  "has_captcha": false,
  "confidence": 0.95
}
```

#### `POST /sessions/{id}/fill` — Fill Form Fields

Fills detected fields using user data + QA bank + LLM generation.

```jsonc
// Request
{
  "user_data": {
    "first_name": "Adam",
    "last_name": "Smith",
    "email": "adam@example.com",
    "phone": "+1234567890",
    "resume_url": "https://storage.supabase.co/resumes/...",
    "skills": ["TypeScript", "React"],
    "years_experience": 5
  },
  "qa_answers": {
    "Are you authorized to work?": "Yes",
    "Desired salary": "150000"
  },
  "resume_file_url": "https://storage.supabase.co/resumes/xyz.pdf"
}

// Response 200
{
  "filled_fields": [
    {
      "name": "firstName",
      "value": "Adam",
      "confidence": 0.99,
      "source": "resume"
    }
    // ...
  ],
  "skipped_fields": [],
  "errors": [],
  "screenshot_url": "s3://artifacts/{task_id}/fill-complete.png"
}
```

#### `POST /sessions/{id}/submit` — Submit Application

Clicks submit and waits for confirmation page.

```jsonc
// Response 200
{
  "success": true,
  "confirmation_id": "APP-12345",
  "confirmation_message": "Your application has been submitted",
  "screenshot_url": "s3://artifacts/{task_id}/confirmation.png",
  "redirect_url": "https://linkedin.com/jobs/applied"
}
```

#### `POST /sessions/{id}/verify` — Verify Submission

Checks the confirmation page for success indicators.

```jsonc
// Response 200
{
  "submitted": true,
  "confirmation_found": true,
  "confirmation_id": "APP-12345",
  "error_messages": [],
  "screenshot_url": "s3://artifacts/{task_id}/verify.png"
}
```

#### `POST /sessions/{id}/continue` — Resume After Human Intervention

Called after user solves CAPTCHA or approves review via VNC.

```jsonc
// Request
{
  "reason": "captcha_solved" | "review_approved",
  "field_overrides": {}  // optional: user-modified field values
}

// Response 200
{ "status": "resumed" }
```

#### `DELETE /sessions/{id}` — Close Session

Closes browser, releases AdsPower profile.

```jsonc
// Response 200
{ "status": "closed", "duration_ms": 145000 }
```

#### `GET /health` — Health Check

```jsonc
// Response 200
{
  "status": "healthy",
  "adspower": "connected",
  "active_sessions": 1,
  "max_sessions": 3,
  "uptime_seconds": 86400
}
```

#### `GET /profiles` — List Profile Status

```jsonc
// Response 200
{
  "profiles": [
    {
      "profile_id": "abc123",
      "status": "idle",     // idle | running | cooling | disabled
      "last_used_at": "2026-02-13T10:00:00Z",
      "consecutive_failures": 0
    }
  ]
}
```

---

## 3. Hatchet Workflow Mapping

### Current 7-Step Workflow → New 5-Step Workflow

The current workflow has 7 fine-grained steps that were designed for mock adapters.
With the EC2 worker handling the actual browser automation, we consolidate:

```
BEFORE (mocked, 7 steps):          AFTER (real, 5 steps):
─────────────────────────           ──────────────────────
start-browser                  →    start-session
analyze-form                   →    analyze-and-fill  (combined)
fill-fields                    ↗
upload-resume                  ↗
check-captcha                  →    (handled inside fill, pauses if detected)
submit                         →    submit-application
verify                         →    verify-and-cleanup
```

### Why Consolidate?

1. **Browser agents work as continuous flows** — Stagehand/Magnitude don't benefit
   from being interrupted between analyze → fill → upload
2. **Reduces HTTP round-trips** — fewer calls between Fly.io and EC2
3. **Keeps meaningful checkpoints** — start, analyze+fill, submit, verify
4. **Human-in-the-loop still works** — EC2 worker pauses and calls back when
   CAPTCHA or review is needed; Hatchet durableTask resumes when resolved

### New Workflow DAG

```
start-session
     │
     ▼
analyze-and-fill (durableTask — may pause for CAPTCHA or copilot review)
     │
     ▼
submit-application (durableTask — may pause for final approval in copilot mode)
     │
     ▼
verify-and-cleanup
```

### Pseudocode

```typescript
// apps/worker/src/workflows/job-application.ts (refactored)

const startSession = workflow.task({
  name: "start-session",
  executionTimeout: "120s",
  fn: async (input, ctx) => {
    // 1. Pick idle profile from pool (via Redis or DB query)
    const profileId = await profilePool.acquireProfile(input.userId);

    // 2. Call EC2 worker
    const session = await ec2Client.createSession({
      taskId: input.taskId,
      profileId,
      jobUrl: input.jobUrl,
      callbackUrl: `${API_URL}/api/v1/webhooks/worker`,
      callbackToken: signWebhookToken(input.taskId),
      mode: input.mode,
    });

    // 3. Publish progress
    await publishProgress(redis, input.userId, {
      type: "progress", taskId: input.taskId,
      step: "start-session", pct: 10,
      message: "Browser started",
      vncUrl: session.vncUrl,  // frontend can show VNC viewer
    });

    return {
      sessionId: session.sessionId,
      profileId,
      vncUrl: session.vncUrl,
    };
  },
});

const analyzeAndFill = workflow.durableTask({
  name: "analyze-and-fill",
  executionTimeout: "300s",  // 5 min for complex forms
  parents: [startSession],
  fn: async (input, ctx) => {
    const prev = await ctx.parentOutput(startSession);

    // 1. Analyze the form
    const analysis = await ec2Client.analyzeForm(prev.sessionId);
    await publishProgress(..., { pct: 30, message: `Detected ${analysis.platform}` });

    // 2. Build user data from resume
    const userData = await buildUserDataFromResume(db, input.userId, input.resumeId);

    // 3. Fill the form
    const fillResult = await ec2Client.fillForm(prev.sessionId, {
      userData, qaAnswers: {}, resumeFileUrl: userData.resumeUrl,
    });

    // 4. If CAPTCHA was detected during fill, EC2 worker already sent callback.
    //    The callback handler pushed "captcha_detected" event to Hatchet.
    //    Wait for resolution:
    if (fillResult.captcha_detected) {
      await publishProgress(..., { type: "human_needed", reason: "CAPTCHA" });
      await ctx.waitFor({ eventKey: "captcha_solved" });
      await ec2Client.continueSession(prev.sessionId, { reason: "captcha_solved" });
    }

    // 5. In copilot mode, send fields for review
    if (input.mode === "copilot") {
      await publishProgress(..., { type: "field_review", fields: fillResult.filledFields });
      const approval = await ctx.waitFor({ eventKey: "review_approved" });
      await ec2Client.continueSession(prev.sessionId, {
        reason: "review_approved",
        fieldOverrides: approval.fieldOverrides ?? {},
      });
    }

    return { sessionId: prev.sessionId, analysis, fillResult };
  },
});

const submitApplication = workflow.task({
  name: "submit-application",
  executionTimeout: "60s",
  parents: [analyzeAndFill],
  fn: async (input, ctx) => {
    const prev = await ctx.parentOutput(analyzeAndFill);
    const result = await ec2Client.submitApplication(prev.sessionId);
    return { sessionId: prev.sessionId, ...result };
  },
});

const verifyAndCleanup = workflow.task({
  name: "verify-and-cleanup",
  executionTimeout: "60s",
  parents: [submitApplication],
  fn: async (input, ctx) => {
    const prev = await ctx.parentOutput(submitApplication);

    // 1. Verify
    const verification = await ec2Client.verifySubmission(prev.sessionId);

    // 2. Close session (releases AdsPower profile)
    await ec2Client.closeSession(prev.sessionId);

    // 3. Release profile back to pool
    await profilePool.releaseProfile(prev.profileId);

    // 4. Publish completion
    await publishProgress(..., { type: "completed", ...verification });

    return verification;
  },
});
```

---

## 4. Session Lifecycle

```
          VALET Worker                    EC2 Worker
          ────────────                    ──────────
               │
               │  POST /sessions
               │  { profile_id, job_url }
               ├────────────────────────────►│
               │                             │ AdsPower: start browser
               │                             │ Xvfb: virtual display
               │                             │ Navigate to job_url
               │◄────────────────────────────┤
               │  { session_id, vnc_url }    │
               │                             │
               │  POST /sessions/{id}/analyze│
               ├────────────────────────────►│
               │                             │ Stagehand: observe page
               │                             │ Detect platform
               │                             │ Map form fields
               │◄────────────────────────────┤
               │  { platform, fields }       │
               │                             │
               │  POST /sessions/{id}/fill   │
               │  { user_data, resume_url }  │
               ├────────────────────────────►│
               │                             │ Fill fields via Stagehand
               │                             │ Upload resume
               │                             │ ─── If CAPTCHA ──────────
               │  callback: captcha_detected │ │ Pause execution       │
               │◄─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ┤ │ Expose VNC            │
               │                             │ │ Wait for /continue    │
               │  (Hatchet waitFor)          │ │                       │
               │  (User solves via VNC)      │ │                       │
               │                             │ │                       │
               │  POST /sessions/{id}/continue                        │
               ├────────────────────────────►│ │ Resume execution      │
               │                             │ ─────────────────────────
               │◄────────────────────────────┤
               │  { filled_fields }          │
               │                             │
               │  POST /sessions/{id}/submit │
               ├────────────────────────────►│
               │                             │ Click submit
               │                             │ Wait for confirmation
               │◄────────────────────────────┤
               │  { success, confirmation }  │
               │                             │
               │  POST /sessions/{id}/verify │
               ├────────────────────────────►│
               │                             │ Screenshot confirmation
               │◄────────────────────────────┤
               │  { submitted: true }        │
               │                             │
               │  DELETE /sessions/{id}      │
               ├────────────────────────────►│
               │                             │ AdsPower: close browser
               │                             │ Clean up temp files
               │◄────────────────────────────┤
               │  { status: "closed" }       │
```

---

## 5. Progress & Callback Protocol

### EC2 → VALET Webhooks

The EC2 worker sends progress updates via HTTP POST to the callback URL provided
when the session was created.

```jsonc
// POST {callback_url}
// Authorization: Bearer {callback_token}
{
  "session_id": "uuid",
  "task_id": "uuid",
  "type": "progress" | "captcha_detected" | "error" | "screenshot",
  "data": {
    "step": "analyzing" | "filling" | "uploading" | "submitting",
    "pct": 45,
    "message": "Filling page 2 of 3",
    "screenshot_url": "s3://artifacts/...",
    // For captcha_detected:
    "captcha_type": "recaptcha_v2",
    "vnc_url": "wss://..."
  },
  "timestamp": "2026-02-13T10:05:30Z"
}
```

### VALET API Webhook Handler

New route in the API server that receives EC2 worker callbacks:

```typescript
// apps/api/src/modules/webhooks/worker-webhook.routes.ts

// POST /api/v1/webhooks/worker
// 1. Verify JWT callback_token
// 2. Based on type:
//    - "progress": Publish to Redis pub/sub → WebSocket → frontend
//    - "captcha_detected": Push Hatchet event "captcha_detected"
//    - "error": Push Hatchet event to fail the workflow step
//    - "screenshot": Store URL in task_events table
```

### Why Webhooks Instead of Polling?

- EC2 worker knows exactly when events happen (captcha appears, field filled)
- Eliminates polling latency and wasted requests
- VALET API already has WebSocket infrastructure for real-time frontend updates
- Single responsibility: EC2 worker focuses on browser work, pushes updates when ready

---

## 6. Human-in-the-Loop

### CAPTCHA Flow

```
1. EC2 worker detects CAPTCHA during form fill
2. EC2 worker pauses execution, keeps browser open
3. EC2 worker sends callback: { type: "captcha_detected", vnc_url }
4. VALET API receives webhook:
   a. Publishes to Redis → WebSocket → frontend shows "CAPTCHA detected" + VNC viewer
   b. Pushes Hatchet event "captcha_detected" (informational)
5. Hatchet durableTask is already in ctx.waitFor({ eventKey: "captcha_solved" })
6. User opens VNC viewer in frontend, solves CAPTCHA manually
7. User clicks "Done" button in frontend
8. Frontend calls VALET API: POST /api/v1/tasks/{id}/captcha-solved
9. VALET API:
   a. Pushes Hatchet event "captcha_solved" → durableTask resumes
   b. Returns success to frontend
10. Hatchet step resumes, calls EC2: POST /sessions/{id}/continue { reason: "captcha_solved" }
11. EC2 worker resumes form fill from where it paused
```

### Copilot Review Flow

```
1. EC2 worker completes form fill, returns filled_fields
2. Hatchet step publishes field_review to frontend via Redis/WebSocket
3. Frontend shows filled fields for user review + VNC viewer
4. User modifies any fields, clicks "Approve & Submit"
5. Frontend calls VALET API: POST /api/v1/tasks/{id}/approve { fieldOverrides }
6. VALET API pushes Hatchet event "review_approved" { fieldOverrides }
7. Hatchet durableTask resumes
8. If fieldOverrides exist: calls EC2 POST /sessions/{id}/continue with overrides
9. EC2 worker applies overrides (re-fills changed fields)
10. Proceeds to submit step
```

### VNC Access

- Each EC2 instance runs Xvfb + x11vnc + websockify (same stack as `01-vnc-stack.md`)
- VNC URL format: `wss://{ec2-public-ip}:6901/websockify?session={session_id}&token={vnc-token}`
- Frontend uses `@novnc/novnc` React component (already designed in `01-vnc-stack.md`)
- Session-scoped VNC tokens prevent unauthorized access
- VNC is read-only by default; "Takeover" button in frontend grants input control

---

## 7. Profile & Pool Management

### Profile Assignment Strategy

Profiles are managed in the VALET database, not on the EC2 worker. The Hatchet
workflow picks an idle profile before calling EC2.

```
profiles table (packages/db):
┌──────────────┬────────────────┬─────────┬───────────────┬─────────────────┐
│ id           │ adspower_id    │ status  │ ec2_instance  │ cooldown_until  │
├──────────────┼────────────────┼─────────┼───────────────┼─────────────────┤
│ uuid         │ "jk8f2a..."   │ idle    │ i-0abc123     │ NULL            │
│ uuid         │ "m3x9k1..."   │ running │ i-0abc123     │ NULL            │
│ uuid         │ "p7w2n4..."   │ cooling │ i-0abc123     │ 2026-02-13T11:00│
└──────────────┴────────────────┴─────────┴───────────────┴─────────────────┘
```

### Profile Pool Service

```typescript
// apps/worker/src/services/profile-pool.ts

export class ProfilePool {
  constructor(private db: Database, private redis: Redis) {}

  /** Acquire an idle profile, mark as running. Uses Redis lock for concurrency. */
  async acquireProfile(userId: string): Promise<string> {
    const lockKey = `profile-lock:${userId}`;
    const lock = await this.redis.set(lockKey, "1", "EX", 10, "NX");
    if (!lock) throw new Error("Profile acquisition in progress");

    try {
      const profile = await this.db
        .select().from(profiles)
        .where(and(
          eq(profiles.status, "idle"),
          or(isNull(profiles.cooldownUntil), lt(profiles.cooldownUntil, new Date()))
        ))
        .orderBy(profiles.lastUsedAt)  // LRU
        .limit(1);

      if (!profile[0]) throw new NoAvailableProfileError();

      await this.db.update(profiles)
        .set({ status: "running", lastUsedAt: new Date() })
        .where(eq(profiles.id, profile[0].id));

      return profile[0].adspowerId;
    } finally {
      await this.redis.del(lockKey);
    }
  }

  /** Release profile back to idle, or set cooldown on failure */
  async releaseProfile(adspowerId: string, failed?: boolean): Promise<void> {
    if (failed) {
      // Exponential cooldown (managed by circuit breaker)
      await this.db.update(profiles)
        .set({ status: "cooling", cooldownUntil: calculateCooldown(adspowerId) })
        .where(eq(profiles.adspowerId, adspowerId));
    } else {
      await this.db.update(profiles)
        .set({ status: "idle" })
        .where(eq(profiles.adspowerId, adspowerId));
    }
  }
}
```

### Why Central Profile Management?

- Multiple Hatchet worker slots may try to acquire profiles concurrently
- Redis distributed lock prevents double-assignment
- Profile cooldown state persists across worker restarts
- EC2 worker doesn't need to know about profile assignment logic

---

## 8. Circuit Breaker & Error Handling

### Profile Circuit Breaker (from axon-browser-worker)

States: `HEALTHY → COOLING → NEEDS_HUMAN → DISABLED`

```
Failure triggers:
- Platform blocks/bans → COOLING (exponential backoff)
  - 1st: 15-30 min
  - 2nd: 2-6 hours
  - 3rd+: needs human review
- 5 consecutive technical failures → DISABLED
- CAPTCHA loop (3+ in a row) → NEEDS_HUMAN

Implemented in: ProfilePool.releaseProfile() + circuit-breaker table
```

### Error Handling in Hatchet Steps

```typescript
// Wrapper for EC2 HTTP calls with retry + error mapping
async function callEc2<T>(
  url: string,
  body: unknown,
  options?: { retries?: number; timeoutMs?: number }
): Promise<T> {
  const { retries = 2, timeoutMs = 30000 } = options ?? {};

  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(timeoutMs),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        // Don't retry on 4xx (client errors)
        if (res.status >= 400 && res.status < 500) {
          throw new EC2WorkerError(err.message ?? res.statusText, false);
        }
        throw new EC2WorkerError(err.message ?? res.statusText, true);
      }

      return res.json() as T;
    } catch (e) {
      if (e instanceof EC2WorkerError && !e.retryable) throw e;
      if (attempt === retries) throw e;
      await new Promise(r => setTimeout(r, 1000 * (attempt + 1)));
    }
  }
  throw new Error("Unreachable");
}
```

### Hatchet Workflow Error Recovery

```
If start-session fails:
  → Release profile back to pool
  → Retry with different profile (up to 3 profiles)
  → If all fail: mark task as "failed", notify user

If analyze-and-fill fails:
  → Close session on EC2 (cleanup)
  → Release profile
  → Retry with same profile after cooldown, or different profile

If submit fails:
  → Screenshot current page
  → Close session
  → Mark task as "needs_human" for manual review

If verify fails:
  → Screenshot current page
  → Close session
  → Mark task as "submitted_unverified"
```

---

## 9. EC2 Golden Image (AMI)

### Pre-baked Software

```
Base: Ubuntu 24.04 LTS (arm64 for Graviton = cheaper, or x86_64)
├── System
│   ├── Xvfb (virtual framebuffer, 1920x1080x24)
│   ├── x11vnc + websockify (VNC access)
│   ├── supervisord (process management)
│   ├── nginx (reverse proxy for VNC + API)
│   └── CloudWatch agent (metrics/logs)
├── Browser
│   ├── AdsPower (latest, auto-update disabled)
│   ├── Chromium (fallback if AdsPower not needed)
│   └── ChromeDriver (matching version)
├── Python
│   ├── Python 3.12
│   ├── FastAPI + uvicorn
│   ├── stagehand (Python SDK)
│   ├── magnitude-browser (Python SDK)
│   ├── selenium + undetected-chromedriver
│   └── playwright (for Stagehand)
├── Node.js 20 (for Stagehand TypeScript if needed)
└── Config
    ├── /etc/supervisor/conf.d/worker.conf
    ├── /opt/worker/          (FastAPI app code)
    ├── /opt/worker/.env      (from Secrets Manager at boot)
    └── systemd timer for log rotation
```

### Packer Build (outline)

```hcl
# packer/ec2-worker.pkr.hcl

source "amazon-ebs" "worker" {
  ami_name      = "valet-worker-{{timestamp}}"
  instance_type = "t3.medium"
  source_ami_filter {
    filters = { "name" = "ubuntu/images/*24.04*amd64*" }
    owners  = ["099720109477"]  # Canonical
  }
  ssh_username = "ubuntu"
}

build {
  sources = ["source.amazon-ebs.worker"]

  provisioner "shell" {
    scripts = [
      "scripts/install-system.sh",    # Xvfb, x11vnc, websockify, supervisord
      "scripts/install-adspower.sh",   # Download + install AdsPower
      "scripts/install-python.sh",     # Python 3.12 + venv + pip deps
      "scripts/install-worker.sh",     # Copy FastAPI app to /opt/worker
      "scripts/configure-supervisor.sh",
    ]
  }
}
```

### Terraform (outline)

```hcl
# terraform/ec2-worker.tf

resource "aws_instance" "browser_worker" {
  count         = var.worker_count  # Start with 1, scale as needed
  ami           = data.aws_ami.worker.id
  instance_type = "t3.medium"

  subnet_id              = aws_subnet.private.id
  vpc_security_group_ids = [aws_security_group.worker.id]
  iam_instance_profile   = aws_iam_instance_profile.worker.name

  user_data = templatefile("userdata.sh", {
    env             = var.environment
    secrets_arn     = aws_secretsmanager_secret.worker.arn
    callback_url    = var.valet_api_url
  })

  tags = { Name = "valet-worker-${var.environment}-${count.index}" }
}

resource "aws_security_group" "worker" {
  ingress {
    from_port   = 8080
    to_port     = 8080
    protocol    = "tcp"
    cidr_blocks = [var.valet_api_cidr]  # Only VALET API can reach worker
  }
  ingress {
    from_port   = 6901
    to_port     = 6901
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]  # VNC (token-protected)
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]  # Outbound for job sites
  }
}
```

---

## 10. Networking & Security

### Traffic Flow

```
User browser ──HTTPS──► VALET API (Fly.io)
                              │
                         HTTP (private) ──► EC2 Worker :8080
                              │
User browser ──WSS───► EC2 Worker :6901 (VNC, token-gated)
                              │
                    EC2 Worker ──► Job sites (outbound via residential proxy)
                    EC2 Worker ──► AdsPower Local API :50325 (localhost)
                    EC2 Worker ──► Supabase Storage (S3, for screenshots/artifacts)
```

### Security Measures

| Concern | Solution |
|---------|----------|
| Worker API auth | JWT tokens issued by VALET API, verified by EC2 worker |
| VNC auth | Session-scoped one-time tokens, expire after 30 min |
| Secrets | AWS Secrets Manager, loaded at boot via IAM role |
| Network isolation | Worker in private subnet, only VALET API CIDR allowed on :8080 |
| VNC encryption | WSS (TLS via nginx reverse proxy on EC2) |
| Callback auth | Signed JWT callback_token, EC2 → VALET API webhook |

### VALET API → EC2: WireGuard vs Public API?

**MVP: Public IP + Security Group + JWT**
- Simple, works immediately
- Security group restricts :8080 to known Fly.io egress IPs
- JWT on every request

**Future: AWS PrivateLink or WireGuard**
- If Fly.io gets PrivateLink support, use it
- Or: WireGuard tunnel between Fly.io worker and EC2 VPC
- Eliminates public exposure of :8080

---

## 11. Cost Model

### Per-Instance Monthly Cost

| Component | Cost/Month | Notes |
|-----------|-----------|-------|
| EC2 t3.medium (1yr RI) | $22.00 | 2 vCPU, 4 GB RAM |
| EBS 30 GB gp3 | $2.40 | OS + AdsPower + logs |
| Data transfer (est.) | $2.00 | ~20 GB outbound |
| Elastic IP | $3.65 | Static IP for profile consistency |
| **Total per instance** | **~$30/mo** | |

### Capacity per Instance

- Each session: ~2-3 min active browser time
- Sessions are sequential (one AdsPower profile at a time per instance)
- ~20-30 sessions/hour → ~480-720 sessions/day per instance
- With 3 AdsPower profiles per instance: can rotate between tasks with no cooldown gap

### Scaling

| Scale | Instances | Sessions/Day | Cost/Month |
|-------|-----------|-------------|-----------|
| MVP | 1 | ~500 | $30 |
| Small | 3 | ~1,500 | $90 |
| Medium | 10 | ~5,000 | $300 |

---

## 12. Implementation Phases

### Phase 1: EC2 Worker MVP (1-2 weeks)

**Goal**: Single EC2 instance running FastAPI + AdsPower, callable from Hatchet.

1. Fork/adapt axon-browser-worker into `infra/ec2-worker/` or separate repo
2. Implement session-based API endpoints (start, analyze, fill, submit, verify, close)
3. Integrate Stagehand Python SDK for form analysis + filling
4. Add webhook callback for progress reporting
5. Create Packer AMI build script
6. Deploy 1x t3.medium manually
7. Verify: Hatchet → HTTP → EC2 → AdsPower → LinkedIn Easy Apply (test account)

### Phase 2: Hatchet Integration (1 week)

**Goal**: Replace mock adapters with real EC2 HTTP calls.

1. Create `EC2WorkerClient` class in `apps/worker/src/services/ec2-client.ts`
2. Create `ProfilePool` service in `apps/worker/src/services/profile-pool.ts`
3. Refactor `job-application.ts` from 7-step to 5-step workflow
4. Add webhook handler route in API server
5. Add `profiles` table to Drizzle schema
6. Wire up CAPTCHA + review human-in-the-loop flows
7. Test end-to-end with copilot mode

### Phase 3: VNC + Human Takeover (1 week)

**Goal**: Working VNC viewer in frontend for CAPTCHA solving.

1. Configure x11vnc + websockify on EC2 AMI
2. Add VNC token generation to session creation
3. Integrate `@novnc/novnc` component in web app (design from `01-vnc-stack.md`)
4. Test CAPTCHA detection → VNC takeover → resume flow

### Phase 4: Magnitude Fallback + Engine Switching (1 week)

**Goal**: Dual-agent architecture (Stagehand primary, Magnitude fallback).

1. Add Magnitude Python SDK to EC2 worker
2. Implement engine switching logic (from `04-engine-switching.md`)
3. If Stagehand fails on a step → screenshot → Magnitude retries via vision
4. Log which engine succeeded for future optimization

### Phase 5: Terraform + Multi-Instance (1 week)

**Goal**: Infrastructure as code, auto-scaling ready.

1. Write Terraform for VPC, security groups, EC2 instances, Secrets Manager
2. Add health check endpoint monitoring (CloudWatch)
3. Auto-recover unhealthy instances
4. Profile distribution across instances

---

## Appendix: EC2 Worker Python Structure

```
infra/ec2-worker/
├── src/
│   ├── server.py              # FastAPI app, routes
│   ├── config.py              # Environment config
│   ├── models.py              # Pydantic request/response models
│   ├── session_manager.py     # Active session tracking
│   ├── adspower/
│   │   ├── client.py          # AdsPower Local API HTTP client
│   │   └── profiles.py        # Profile start/stop helpers
│   ├── browser/
│   │   ├── session.py         # BrowserSession context manager
│   │   ├── humanize.py        # Human-like input simulation
│   │   └── screenshot.py      # Screenshot capture + S3 upload
│   ├── agents/
│   │   ├── stagehand_agent.py # Stagehand SDK wrapper
│   │   ├── magnitude_agent.py # Magnitude SDK wrapper
│   │   └── orchestrator.py    # Engine switching logic
│   ├── handlers/
│   │   ├── analyze.py         # Form analysis handler
│   │   ├── fill.py            # Form filling handler
│   │   ├── submit.py          # Submit + confirmation handler
│   │   └── verify.py          # Post-submit verification
│   └── callbacks/
│       └── webhook.py         # Send progress to VALET API
├── tests/
├── requirements.txt
├── supervisord.conf
├── Dockerfile                 # For local dev/testing
└── README.md
```

### Key Difference from axon-browser-worker

| Aspect | axon-browser-worker | VALET EC2 Worker |
|--------|--------------------|--------------------|
| Session model | Stateless (one call = full task) | Session-based (browser stays open) |
| Agent | Selenium only | Stagehand + Magnitude + Selenium fallback |
| Progress | Returns final result only | Webhooks for real-time progress |
| Human-in-the-loop | Not supported | CAPTCHA pause + VNC + /continue endpoint |
| Task types | Generic (scroll, click, input) | Job application specific (analyze, fill, submit) |
| Orchestration | Self-contained | Orchestrated by Hatchet |
